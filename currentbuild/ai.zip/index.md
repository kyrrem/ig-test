# Home - EHIN FHIR Hackaton - Aidn. v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://aidn.no/ehin/fhir/hackaton/ImplementationGuide/ehin.fhir.hackaton.aidn.no | *Version*:0.1.0 |
| Draft as of 2025-11-10 | *Computable Name*:EHINFHIRHackatonAidn |

### Tittel

Introduksjonstekst (husk at dette er en mal, og ALL tekst må endres - dette er kun et eksempel)

### Mål

Målet med denne implementasjonsguiden er å gi en standardisert måte å representere og utveksle helsedata på ved hjelp av HL7 FHIR. Guiden beskriver hvordan ulike FHIR-profiler og ressurser kan brukes for å oppnå interoperabilitet mellom helsesystemer.

### Omfang

Denne implementasjonsguiden dekker følgende områder:

* Pasientadministrasjon
* Kliniske observasjoner
* Medisinsk historikk
* Behandlingsplaner
* Laboratorieresultater

### Brukstilfeller

#### Pasientregistrering

Denne guiden beskriver hvordan pasienter kan registreres i et helsesystem ved hjelp av FHIR `Patient`-ressursen. Eksempler inkluderer opprettelse, oppdatering og sletting av pasientdata.

#### Kliniske observasjoner

Guiden viser hvordan kliniske observasjoner som blodtrykk, puls og temperatur kan representeres ved hjelp av FHIR `Observation`-ressursen.

### Figur

Eksempel på en figur laget med PlantUML.

![](test.svg)

